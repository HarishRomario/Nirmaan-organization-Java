package day18;

public interface Icalculator {
	abstract void add(int a, int b);
	abstract void sub(int a, int b);
	abstract void mul(int a, int b);
	abstract void div(int a, int b);
	abstract void mod(int a, int b);
	

	
	}


