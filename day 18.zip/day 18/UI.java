package day18;

public class UI {

	public static void main(String[] args) {
		Calculator sc = new Calculator();
		sc.add(11,12);
		sc.sub(56,88);
		sc.mul(22,33);
		sc.div(11,55);
		sc.mod(66,78);


	}

}
