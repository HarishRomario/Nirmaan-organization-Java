package day14;

public class StringMethods {
	public static void  main(String args[]) {
		String a= "name";
		String b= "janagamana";
		//System.out.println(a.charAt(3));
		//System.out.println(b.substring(4,6));
		System.out.println(a.toLowerCase() + " "+ b.toLowerCase());
		System.out.println(a.toUpperCase() + " " + b.toLowerCase());
		System.out.println(a.equalsIgnoreCase(b));
		System.out.println(b.contains("x"));
	}

}
