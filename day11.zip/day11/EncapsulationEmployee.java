package day11;

public class EncapsulationEmployee {
	
	private int employeeID;
	private String name;
	private double salary;
	private String from;
	
	public void setEmployeeID(int ID) {
		employeeID= ID;
	}

	public void setName (String name1) {
		name=name1;
	}
	
	public void setSalary(double Salary) {
		salary=Salary;
	}
	public void setFrom (String From) {
		from=From;
		
	}
	
	public int getEmployeeID() { 
		return employeeID;
	}
	public String getName() {
		return name;
	}
	public double getSalary() {
		return salary;
	}
	public String getFrom() {
		return from;
	}
}
