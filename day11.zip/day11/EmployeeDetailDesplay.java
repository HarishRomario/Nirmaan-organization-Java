package day11;

public class EmployeeDetailDesplay {

	public static void main(String[] args) {
		EncapsulationEmployee emp= new EncapsulationEmployee();
		emp.setEmployeeID(101);
		emp.setName("harish");
		emp.setSalary(80000);
		emp.setFrom("Trichy");
		System.out.println(emp.getEmployeeID());
		System.out.println(emp.getName());
		System.out.println(emp.getSalary());
		System.out.println(emp.getFrom());
	

	}

}
