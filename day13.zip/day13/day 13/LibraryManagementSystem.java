package day13;

import java.util.Scanner;

public class LibraryManagementSystem {
	private int id;
	private String bookname;
	private String Author;
	private int price;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		Author = author;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	
	@Override
	public String toString() {
		return "LibraryManagementSystem [id=" + id + ", bookname=" + bookname + ", Author=" + Author + ", price="
				+ price + "]";
	}

	public LibraryManagementSystem(int id, String bookname, String author, int price) {
		super();
		this.id = id;
		this.bookname = bookname;
		Author = author;
		this.price = price;
	}

	public static void main(String[] args) {
		LibraryManagementSystem lib = new LibraryManagementSystem(11,"harrypotter","prasana",54);
		
		System.out.println(lib);

	}

}
