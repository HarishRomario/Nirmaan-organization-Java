package day13;

public class ToStringMethod {
	private static final String ToStringMethod = null;
	public int id;
	public String name;
	ToStringMethod (int id, String name){
		this.id=id;
		this.name=name;
		
	}
	 public int getid() {
	 return id;
		 
	 }
	 public String getname() {
	 return name;
		 
	 }
	 public void  setid(int id) {
		 this.id=id;
		 
	 }
	 public void setName(String name) {
		 this.name=name;
	 }
	 
	 
	 public String toString() {
		 return "your id : "+id+"\nyour name : "+name;
	 }
			
	public static void main(String[] args) {
		ToStringMethod df = new ToStringMethod(5,"mohan");
		System.out.println(df);

	}

}
