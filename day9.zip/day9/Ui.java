package day10;

import java.util.Scanner;

public class Ui {

	public static void main(String[] args) {
		Calculator cal= new Calculator();
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the first number:");
		int num1=sc.nextInt();
		System.out.println("Enter the Second number:");
		int num2=sc.nextInt();
		cal.add(num1,num2);
		cal.sub(num1,num2);
		cal.mul(num1, num2);
		cal.div(num1, num2);
		cal.Mod(num1, num2);

	}

}
