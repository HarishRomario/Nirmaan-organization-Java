package Day6;

import java.util.Scanner;

public class ForloopEX {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the numeber: ");
		
		for(int i=1;i<=3;i++) {
			System.out.println("raj");
		}

	}

}
