package day16;

public class BikeInheritance  extends VehicalInheritance {

	void kickStart() {
		
		System.out.println("bike is kick Strated....");

	}

}
