package day16;

public class CarInheritance extends VehicalInheritance {
	void drive() {
		System.out.println("Car is driving....");
	}

}
