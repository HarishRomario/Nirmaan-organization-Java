package day16;

public class ElectricInheritance extends CarInheritance {

void chargeBattery() {
	System.out.println("Electric car is starting....");
}

}
