package day16;

public class MainInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CarInheritance car=new CarInheritance();
		car.drive();
		car.startEngine();
		
		
		ElectricInheritance ev=new ElectricInheritance();
		ev.chargeBattery();
		ev.startEngine();
		
		BikeInheritance bike= new BikeInheritance();
		bike.kickStart();
		bike.startEngine();
	

	}

}
