package day16;

public class VehicalInheritance {

void startEngine() {
	System.out.println("Vehical Engine Started");
}

}
